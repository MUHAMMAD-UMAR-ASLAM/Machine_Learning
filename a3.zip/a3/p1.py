import sys, grader, parse,random
from collections import Counter
def pre_process(problem):

 

    pr= problem.split("\n")

    x=pr[4].split()
    x=x+pr[5].split()
    x=x+pr[6].split()


    
    
    z=0
    problem=[[ 0 for i in range(4)]for y in range(3)]
    for i in range(3):
        for y in range(4):
            problem[i][y]=x[z]
            z=z+1
    
 
    po=pr[8]+pr[9]+pr[10]
    po=po.replace("\n","")
   
    po=po.split()
    

    policy=[[ 0 for i in range(4)]for y in range(3)]
    z=0
    for i in range(3):
        for y in range(4):
            policy[i][y]=po[z]
            z=z+1
    
    return (problem,policy)
    
def action(intended,seed,pos):
    if intended=='exit':
        return 'exit'
    random.seed(seed, version=1)
    n = 0.1 #noise
    a = intended #intended action
    d = {'N':['N', 'E', 'W'], 'E':['E', 'S', 'N'], 'S':['S', 'W', 'E'], 'W':['W', 'N', 'S']}
    l = [] 
    for _ in range(100000):
        l += random.choices(population=d[a], weights=[1 - n*2, n, n])[0]
    # print(Counter(l).keys()) # equals to list(set(words))
    # print(Counter(l).values()) # counts the elements' frequency
    return l[pos]

def find(ch,problem):
    row=len(problem)
    column=len(problem[0])
    for i in range(row):
        for j in range(column):
            if ch==problem[i][j]:
                return (i,j)



def swap(index,prob,ft,start_index,total):
        if index==None:
            reward(1, total)
            return
        if index=="exit":
            ft[1]=1
            reward(ft[0], total)
            return
        if prob[index[0]][index[1]]=='1':
            ft[0]=2
        if prob[index[0]][index[1]]=='-1':
            ft[0]=3

       

        

            
        pl_index=find("P", prob)
        prob[index[0]][index[1]]='P'
        prob[pl_index[0]][pl_index[1]]="_"
        reward(1, total)
        if ft[0]==0:
            ft[0]=1
            prob[start_index[0]][start_index[1]]="S"
           


def intended_action(info,index):
    return info[index[0]][index[1]]

    


def move_to(act,index,problem):
     row=len(problem)
     column=len(problem[0])
 
     if act=="E":
        if index[0]>=0 and index[1]+1<column:
            if problem[index[0]][index[1]+1]!="#":
                return (index[0],index[1]+1)
     elif act=="N":
        if index[0]-1>=0 and index[1]<column:
            if problem[index[0]-1][index[1]]!="#":
                return (index[0]-1,index[1])
     elif act=="S":
        if index[0]+1<row and index[1]>=0:
            if problem[index[0]+1][index[1]]!="#":
                return (index[0]+1,index[1])
     elif act=="W":
        if index[0]>=0 and index[1]-1>=0:
           
            if problem[index[0]][index[1]-1]!="#":
                return (index[0],index[1]-1)
     elif act=="exit":
        return "exit"

def reward(type,total):
    reward=-0.05
    if type==1:
        total[1]=reward
        total[0]= round(total[0]+reward,2)
        
    elif type==2:
        total[2]=1
        total[0]= round(total[0]+1,2)
    else:
        total[2]=-1
        total[0]= round(total[0]-1,2)
        
    








def play_episode(problem):

    turn=0
    info=pre_process(problem)
    problem=info[0]
    pol=info[1]
    start="Start state:\n    _    _    _    1\n    _    #    _    -1\n    P    _    _    _\nCumulative reward sum: 0.0\n"
    index=find('S', problem)
    start_index=index
    problem[index[0]][index[1]]="P"
    ft=[0,0]
    total=[0,0,0]
    
    
    turn=0
    while ft[1]!=1:
        start=start+"--------------------------------------------\n"
        index=find('P', problem)
        intend=intended_action(pol, index)
        act=action(intend, 2, turn)
        start=start+"Taking action: "+act+ " (intended: "+intend+")\n"
        mv_index=move_to(act, index, problem)
        
        swap(mv_index,problem,ft,start_index,total)
        start=start+"Reward received: "+str(total[1])+"\n"
        start=start+"New state:\n"
        row=len(problem)
        column=len(problem[0])
        for i in range(row):
            for j in range(column):
                start=start+"    "+problem[i][j]
            start=start+"\n"
            
        start=start+"Cumulative reward sum: "+str(total[0])+"\n"
        turn+=1
    
    experience = start
    return experience

if __name__ == "__main__":
    play_episode(1)
    test_case_id = int(sys.argv[1])
    #test_case_id = 1
    problem_id = 1
    grader.grade(problem_id, test_case_id, play_episode, parse.read_grid_mdp_problem_p1)