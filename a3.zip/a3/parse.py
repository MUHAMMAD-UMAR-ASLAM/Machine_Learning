import os, sys
def read_grid_mdp_problem_p1(file_path):
    pro_read=open(file_path)
    problem=pro_read.read()
    return problem
    

def read_grid_mdp_problem_p2(file_path):
    #Your p2 code here
    problem = ''
    return problem

def read_grid_mdp_problem_p3(file_path):
    #Your p3 code here
    problem = ''
    return problem